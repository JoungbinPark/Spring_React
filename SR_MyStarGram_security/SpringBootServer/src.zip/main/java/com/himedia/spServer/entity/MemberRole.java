package com.himedia.spServer.entity;

public enum MemberRole {
    USER, ADMIN, MANAGER
}
