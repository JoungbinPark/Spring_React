package com.himedia.spServer.security.util;

public class CustomJWTException extends Throwable {
    public CustomJWTException(String msg) {
        super(msg);
    }
}
